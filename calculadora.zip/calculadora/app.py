from flask import Flask, render_template, request

app = Flask(__name__)

@app.route("/", methods=["GET", "POST"])
def calculadora_imc():
    imc = None
    categoria = ""
    if request.method == "POST":
        try:
            peso = float(request.form["peso"])
            altura = float(request.form["altura"])
            imc = round(peso / (altura ** 2), 2)

            if imc < 18.5:
                categoria = "Bajo peso"
            elif 18.5 <= imc < 24.9:
                categoria = "Peso normal"
            elif 25 <= imc < 29.9:
                categoria = "Sobrepeso"
            else:
                categoria = "Obesidad"
        except:
            imc = None
            categoria = "Error en los datos ingresados"

    return render_template("index.html", imc=imc, categoria=categoria)

if __name__ == "__main__":
    app.run(debug=True)
