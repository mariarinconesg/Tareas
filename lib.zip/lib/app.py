from flask import Flask, render_template, request, redirect, url_for
import sqlite3

app = Flask(__name__)

def init_db():
    conn = sqlite3.connect('libertadores.db')
    cursor = conn.cursor()
    cursor.execute('''
        CREATE TABLE IF NOT EXISTS facultad (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            nombre TEXT NOT NULL
        )
    ''')
    cursor.execute('''
        CREATE TABLE IF NOT EXISTS docente (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            nombre TEXT NOT NULL,
            edad INTEGER NOT NULL,
            facultad INTEGER NOT NULL,
            FOREIGN KEY (facultad) REFERENCES facultad(id)
        )
    ''')
    conn.commit()
    conn.close()

init_db()

@app.route('/')
def index():
    conn = sqlite3.connect('libertadores.db')
    cursor = conn.cursor()
    cursor.execute('''
        SELECT docente.id, docente.nombre, docente.edad, facultad.nombre
        FROM docente
        JOIN facultad ON docente.facultad = facultad.id
    ''')
    docentes = cursor.fetchall()
    cursor.execute("SELECT * FROM facultad")
    facultades = cursor.fetchall()
    conn.close()
    return render_template('index.html', vista='docentes', docentes=docentes, facultades=facultades)

@app.route('/facultades')
def facultades():
    conn = sqlite3.connect('libertadores.db')
    cursor = conn.cursor()
    cursor.execute("SELECT * FROM facultad")
    facultades = cursor.fetchall()
    conn.close()
    return render_template('index.html', vista='facultades', facultades=facultades)

@app.route('/add', methods=['POST'])
def add():
    nombre = request.form['nombre']
    edad = request.form['edad']
    facultad_id = request.form['facultad']
    conn = sqlite3.connect('libertadores.db')
    cursor = conn.cursor()
    cursor.execute("INSERT INTO docente (nombre, edad, facultad) VALUES (?, ?, ?)", (nombre, edad, facultad_id))
    conn.commit()
    conn.close()
    return redirect(url_for('index'))

@app.route('/edit/<int:id>')
def edit(id):
    conn = sqlite3.connect('libertadores.db')
    cursor = conn.cursor()
    cursor.execute("SELECT * FROM docente WHERE id=?", (id,))
    docente = cursor.fetchone()
    cursor.execute("SELECT * FROM facultad")
    facultades = cursor.fetchall()
    conn.close()
    return render_template('edit.html', docente=docente, facultades=facultades)

@app.route('/update/<int:id>', methods=['POST'])
def update(id):
    nombre = request.form['nombre']
    edad = request.form['edad']
    facultad_id = request.form['facultad']
    conn = sqlite3.connect('libertadores.db')
    cursor = conn.cursor()
    cursor.execute("UPDATE docente SET nombre=?, edad=?, facultad=? WHERE id=?", (nombre, edad, facultad_id, id))
    conn.commit()
    conn.close()
    return redirect(url_for('index'))

@app.route('/delete/<int:id>')
def delete(id):
    conn = sqlite3.connect('libertadores.db')
    cursor = conn.cursor()
    cursor.execute("DELETE FROM docente WHERE id=?", (id,))
    conn.commit()
    conn.close()
    return redirect(url_for('index'))

@app.route('/facultades/add', methods=['POST'])
def facultades_add():
    nombre = request.form['nombre']
    conn = sqlite3.connect('libertadores.db')
    cursor = conn.cursor()
    cursor.execute("INSERT INTO facultad (nombre) VALUES (?)", (nombre,))
    conn.commit()
    conn.close()
    return redirect(url_for('facultades'))

@app.route('/facultades/delete/<int:id>')
def facultades_delete(id):
    conn = sqlite3.connect('libertadores.db')
    cursor = conn.cursor()
    cursor.execute("DELETE FROM facultad WHERE id=?", (id,))
    conn.commit()
    conn.close()
    return redirect(url_for('facultades'))

if __name__ == '__main__':
    app.run(debug=True)