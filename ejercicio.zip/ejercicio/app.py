from flask import Flask, render_template, request

app = Flask(__name__)

@app.route('/')
def inicio():
    return render_template('inicio.html')

@app.route("/calculadora", methods=["GET", "POST"])
def calculadora():
    imc = None
    categoria = ""
    if request.method == "POST":
        try:
            peso = float(request.form["peso"])
            altura = float(request.form["altura"])
            imc = round(peso / (altura ** 2), 2)

            if imc < 18.5:
                categoria = "Bajo peso"
            elif 18.5 <= imc < 24.9:
                categoria = "Peso normal"
            elif 25 <= imc < 29.9:
                categoria = "Sobrepeso"
            else:
                categoria = "Obesidad"
        except:
            imc = None
            categoria = "Error en los datos ingresados"

    return render_template("calculadora.html", imc=imc, categoria=categoria)

@app.route('/declaracion', methods=["GET", "POST"])
def declaracion():
    resultado = None
    if request.method == "POST":
        patrimonio = int(request.form["patrimonio"])
        ingresos = int(request.form["ingresos"])
        tarjetas = int(request.form["tarjetas"])
        compras = int(request.form["compras"])
        consignaciones = int(request.form["consignaciones"])

        if patrimonio >= 21179300 or ingresos >= 65891000 or tarjetas >= 65891000 or compras >= 65891000 or consignaciones >= 65891000:
            resultado = "Usted debe declarar renta"
        else:
            resultado = "Usted NO debe declarar renta"

    return render_template("declaracion.html", resultado=resultado)

if __name__ == "__main__":
    app.run(debug=True)