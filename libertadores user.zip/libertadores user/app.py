from flask import Flask, render_template, request, redirect, url_for, session, flash
import sqlite3
from functools import wraps

app = Flask(__name__)
app.secret_key = 'a4f8b23c9d67e92b7f1e3a3d8e2c1b9a'


# ============================================
# ----------- INICIALIZAR BASE DATOS ---------
# ============================================
def init_db():
    conn = sqlite3.connect('libertadores.db')
    cursor = conn.cursor()

    # Tabla de facultades
    cursor.execute('''
        CREATE TABLE IF NOT EXISTS facultad (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            nombre TEXT NOT NULL
        )
    ''')

    # Tabla de docentes
    cursor.execute('''
        CREATE TABLE IF NOT EXISTS docente (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            nombre TEXT NOT NULL,
            edad INTEGER NOT NULL,
            facultad INTEGER NOT NULL,
            FOREIGN KEY (facultad) REFERENCES facultad(id)
        )
    ''')

    # Tabla de usuarios
    cursor.execute('''
        CREATE TABLE IF NOT EXISTS usuarios (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            username TEXT UNIQUE NOT NULL,
            password TEXT NOT NULL,
            rol TEXT DEFAULT 'user'
        )
    ''')

    # Crear admin por defecto
    cursor.execute("SELECT * FROM usuarios WHERE username=?", ('admin',))
    if cursor.fetchone() is None:
        cursor.execute(
            "INSERT INTO usuarios (username, password, rol) VALUES (?, ?, ?)",
            ('admin', '1234', 'admin')
        )

    conn.commit()
    conn.close()


init_db()


# ============================================
# ------------------ DECORADORES --------------
# ============================================
def login_required(f):
    @wraps(f)
    def decorated(*args, **kwargs):
        if "username" not in session:
            flash("Debes iniciar sesión.", "warning")
            return redirect(url_for("login"))
        return f(*args, **kwargs)
    return decorated


def admin_required(f):
    @wraps(f)
    def decorated(*args, **kwargs):
        if session.get("rol") != "admin":
            flash("No tienes permisos para realizar esta acción.", "danger")
            return redirect(url_for("index"))
        return f(*args, **kwargs)
    return decorated


@app.after_request
def no_cache(response):
    response.headers["Cache-Control"] = "no-store"
    return response


# ============================================
# ------------------- LOGIN ------------------
# ============================================

@app.route('/login', methods=['GET', 'POST'])
def login():
    if request.method == 'POST':

        username = request.form['username']
        password = request.form['password']

        conn = sqlite3.connect('libertadores.db')
        cursor = conn.cursor()
        cursor.execute("SELECT * FROM usuarios WHERE username=? AND password=?", (username, password))
        user = cursor.fetchone()
        conn.close()

        if user:
            session['username'] = username
            session['rol'] = user[3]
            flash("Inicio de sesión exitoso", "success")
            return redirect(url_for('index'))
        else:
            flash("Credenciales incorrectas", "danger")

    return render_template('login.html')


@app.route('/register', methods=['GET', 'POST'])
def register():
    if request.method == 'POST':

        username = request.form['username']
        password = request.form['password']

        conn = sqlite3.connect('libertadores.db')
        cursor = conn.cursor()

        try:
            cursor.execute("INSERT INTO usuarios (username, password) VALUES (?, ?)", (username, password))
            conn.commit()
            flash("Cuenta creada correctamente. Ahora inicia sesión.", "success")
            return redirect(url_for('login'))

        except sqlite3.IntegrityError:
            flash("El usuario ya existe.", "danger")

        conn.close()

    return render_template('register.html')


@app.route('/logout')
def logout():
    session.clear()
    flash("Sesión cerrada.", "info")
    return redirect(url_for('login'))


# ============================================
# -------------------- VISTAS ----------------
# ============================================

@app.route('/')
@login_required
def index():
    return render_template("home.html", rol=session.get("rol"))


@app.route('/docentes')
@login_required
def ver_docentes():
    conn = sqlite3.connect('libertadores.db')
    cursor = conn.cursor()

    cursor.execute("""
        SELECT docente.id, docente.nombre, docente.edad, facultad.nombre
        FROM docente
        JOIN facultad ON docente.facultad = facultad.id
    """)
    docentes = cursor.fetchall()

    cursor.execute("SELECT * FROM facultad")
    facultades = cursor.fetchall()

    conn.close()

    return render_template('docentes.html', docentes=docentes, facultades=facultades, rol=session.get("rol"))


@app.route('/facultades')
@login_required
def facultades():
    conn = sqlite3.connect('libertadores.db')
    cursor = conn.cursor()
    cursor.execute("SELECT * FROM facultad")
    facultades = cursor.fetchall()
    conn.close()

    return render_template('facultades.html', facultades=facultades, rol=session.get("rol"))


# ============================================
# ---------------- CRUD DOCENTES --------------
# ============================================

@app.route('/add', methods=['POST'])
@login_required
@admin_required
def add():
    nombre = request.form['nombre']
    edad = request.form['edad']
    facultad = request.form['facultad']

    conn = sqlite3.connect('libertadores.db')
    cursor = conn.cursor()
    cursor.execute("INSERT INTO docente (nombre, edad, facultad) VALUES (?, ?, ?)",
                   (nombre, edad, facultad))
    conn.commit()
    conn.close()

    flash("Docente agregado correctamente", "success")
    return redirect(url_for('ver_docentes'))


@app.route('/edit/<int:id>')
@login_required
@admin_required
def edit(id):
    conn = sqlite3.connect('libertadores.db')
    cursor = conn.cursor()

    cursor.execute("SELECT * FROM docente WHERE id=?", (id,))
    docente = cursor.fetchone()

    cursor.execute("SELECT * FROM facultad")
    facultades = cursor.fetchall()

    conn.close()

    return render_template('edit.html', docente=docente, facultades=facultades)


@app.route('/update/<int:id>', methods=['POST'])
@login_required
@admin_required
def update(id):
    nombre = request.form['nombre']
    edad = request.form['edad']
    facultad = request.form['facultad']

    conn = sqlite3.connect('libertadores.db')
    cursor = conn.cursor()
    cursor.execute("UPDATE docente SET nombre=?, edad=?, facultad=? WHERE id=?",
                   (nombre, edad, facultad, id))
    conn.commit()
    conn.close()

    flash("Docente actualizado correctamente", "info")
    return redirect(url_for('ver_docentes'))


@app.route('/delete/<int:id>')
@login_required
@admin_required
def delete(id):
    conn = sqlite3.connect('libertadores.db')
    cursor = conn.cursor()
    cursor.execute("DELETE FROM docente WHERE id=?", (id,))
    conn.commit()
    conn.close()

    flash("Docente eliminado", "danger")
    return redirect(url_for('ver_docentes'))


# ============================================
# ---------------- CRUD FACULTADES -----------
# ============================================

@app.route('/facultades/add', methods=['POST'])
@login_required
@admin_required
def facultades_add():
    nombre = request.form['nombre']

    conn = sqlite3.connect('libertadores.db')
    cursor = conn.cursor()
    cursor.execute("INSERT INTO facultad (nombre) VALUES (?)", (nombre,))
    conn.commit()
    conn.close()

    flash("Facultad agregada", "success")
    return redirect(url_for('facultades'))


@app.route('/facultades/delete/<int:id>')
@login_required
@admin_required
def facultades_delete(id):
    conn = sqlite3.connect('libertadores.db')
    cursor = conn.cursor()
    cursor.execute("DELETE FROM facultad WHERE id=?", (id,))
    conn.commit()
    conn.close()

    flash("Facultad eliminada", "danger")
    return redirect(url_for('facultades'))


# ============================================
# ------------------- RUN APP ----------------
# ============================================

if __name__ == '__main__':
    app.run(debug=True)
