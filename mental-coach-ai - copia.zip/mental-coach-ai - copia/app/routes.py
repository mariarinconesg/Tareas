from flask import Blueprint, render_template, request, redirect, url_for, jsonify
import markdown
import random
import requests
import os
import json
from dotenv import load_dotenv
from app.gemini import responder_a_usuario

# Cargar helpers
from app.utils import cargar_historial, guardar_historial

load_dotenv()
PEXELS_API_KEY = os.getenv("PEXELS_API_KEY")

main = Blueprint('main', __name__)

# Frases motivacionales por tipo
frases = {
    'general': [
        "El único modo de hacer un gran trabajo es amar lo que haces. – Steve Jobs",
        "Haz hoy lo que otros no quieren, haz mañana lo que otros no pueden.",
        "El éxito es la suma de pequeños esfuerzos repetidos día tras día. – Robert Collier",
        "Nunca es demasiado tarde para ser lo que podrías haber sido. – George Eliot",
        "La vida comienza donde termina la zona de confort.",
        "La mayor gloria no está en no caer nunca, sino en levantarnos cada vez que caemos. – Confucio",
        "Hazlo con pasión o no lo hagas en absoluto. – Rosa Nouchette Carey"
    ],
    'superacion': [
        "La diferencia entre quien eres y quien quieres ser, está en lo que haces.",
        "El dolor es temporal, el orgullo es para siempre.",
        "Tu vida no mejora por casualidad, mejora por cambio. – Jim Rohn",
        "La adversidad no es un obstáculo, es una oportunidad para crecer.",
        "La única forma de hacer un excelente trabajo es amar lo que haces. – Steve Jobs",
        "No dejes que el miedo te detenga. El mayor riesgo es no tomar ninguno.",
        "Lo que no te mata te fortalece. – Friedrich Nietzsche"
    ],
    'resiliencia': [
        "Caer está permitido, levantarse es obligatorio.",
        "No te rindas, cada intento fallido es una lección que te acerca al éxito.",
        "Lo que no te mata, te hace más fuerte. – Friedrich Nietzsche",
        "La verdadera fortaleza es encontrar la paz en medio de la tormenta.",
        "El agua se adapta a su entorno, tú también puedes adaptarte a los cambios.",
        "No importa cuántas veces caigas, lo que importa es cuántas veces te levantes.",
        "La resiliencia es la capacidad de transformar la adversidad en fuerza."
    ],
    'positivos': [
        "La actitud es una pequeña cosa que marca una gran diferencia. – Winston Churchill",
        "El optimismo es la fe que lleva al logro. – Helen Keller",
        "Cambia tus pensamientos y cambiarás tu mundo. – Norman Vincent Peale",
        "Lo que piensas, lo creas. Mantén pensamientos positivos.",
        "Mantén tu cara siempre hacia el sol y las sombras quedarán detrás de ti. – Walt Whitman",
        "El futuro pertenece a quienes creen en la belleza de sus sueños. – Eleanor Roosevelt",
        "Cada día es una nueva oportunidad para cambiar tu vida."
    ],
    'persistencia': [
        "La clave del éxito es la constancia.",
        "No se trata de cuántas veces caes, sino de cuántas te levantas.",
        "La perseverancia es la madre del éxito.",
        "Hazlo con pasión o no lo hagas en absoluto.",
        "La disciplina es el puente entre tus metas y tus logros. – Jim Rohn",
        "El fracaso no es la caída, sino quedarse allí. – Mary Pickford",
        "La perseverancia es el trabajo duro que haces después de que te cansas de hacer el trabajo duro."
    ],
    'exito': [
        "El éxito no es la clave de la felicidad. La felicidad es la clave del éxito. – Albert Schweitzer",
        "El éxito es la habilidad de ir de fracaso en fracaso sin perder el entusiasmo. – Winston Churchill",
        "El éxito es un viaje, no un destino.",
        "El único límite para nuestros logros de mañana está en nuestras dudas de hoy. – Franklin D. Roosevelt",
        "El éxito es hacer lo que amas, no lo que otros esperan de ti.",
        "No te detengas cuando estés cansado, detente cuando hayas terminado.",
        "La clave del éxito está en creer en ti mismo, incluso cuando los demás no lo hacen."
    ],
    'accion': [
        "No esperes por la oportunidad, créala.",
        "La acción es la llave fundamental para todo éxito. – Pablo Picasso",
        "El tiempo que esperas, es tiempo que puedes usar para avanzar.",
        "Hazlo o no lo hagas, pero no lo intentes. – Yoda",
        "Cada paso hacia adelante es una victoria, no importa cuán pequeño sea.",
        "Las grandes oportunidades nacen de haber sabido aprovechar las pequeñas.",
        "El momento de actuar es ahora, no mañana."
    ],
    'confianza': [
        "Confía en ti mismo y todo será posible.",
        "Tienes todo lo que necesitas para alcanzar tus sueños dentro de ti.",
        "No eres lo que otros piensan de ti, eres lo que tú decides ser.",
        "La confianza en uno mismo es el primer paso hacia cualquier éxito.",
        "La mayor de las confianzas comienza en ti mismo.",
        "Confía en el proceso, incluso si no ves los resultados inmediatos.",
        "No esperes que otros crean en ti si no crees en ti mismo primero."
    ]
}
CHAT_DIR = "historiales"

if not os.path.exists(CHAT_DIR):
    os.makedirs(CHAT_DIR)

def listar_chats():
    archivos = os.listdir(CHAT_DIR)
    return [archivo.replace(".json", "") for archivo in archivos if archivo.endswith(".json")]

def ruta_chat(nombre_chat):
    return os.path.join(CHAT_DIR, f"{nombre_chat}.json")

def cargar_chat(nombre_chat):
    ruta = os.path.join('historiales', f'{nombre_chat}.json')
    if not os.path.exists(ruta):
        return []
    with open(ruta, 'r', encoding='utf-8') as f:
        try:
            contenido = f.read().strip()
            if not contenido:
                return []
            return json.loads(contenido)
        except json.JSONDecodeError:
            print(f"⚠️ Error al cargar el archivo {ruta}: formato JSON inválido")
            return []


def guardar_chat(nombre_chat, historial):
    ruta = ruta_chat(nombre_chat)
    with open(ruta, 'w', encoding='utf-8') as f:
        json.dump(historial, f, ensure_ascii=False, indent=2)

def eliminar_chat(nombre_chat):
    ruta = ruta_chat(nombre_chat)
    if os.path.exists(ruta):
        os.remove(ruta)

# ------------------- RUTAS MOTIVACIONALES ----------------------

@main.route('/motivacion')
def motivacion():
    headers = {
        "Authorization": PEXELS_API_KEY
    }

    filtro = request.args.get("tipo", "dogs")
    params = {"query": filtro, "per_page": 50}
    response = requests.get("https://api.pexels.com/v1/search", headers=headers, params=params)

    imagenes = []
    if response.status_code == 200:
        datos = response.json()
        imagenes = [foto["src"]["medium"] for foto in datos["photos"]]

    frases_aleatorias = [random.choice(frases['general']) for _ in imagenes]
    galeria = list(zip(imagenes, frases_aleatorias))
    return render_template('motivacion.html', galeria=galeria, tipo=filtro)

# ------------------- RUTAS BASE ----------------------

@main.route('/')
def inicio():
    return render_template('index.html')

@main.route('/home')
def home():
    return render_template('index.html')

@main.route('/consejos')
def consejos():
    return render_template('consejos.html')

@main.route('/frase/<tipo>')
def obtener_frase(tipo):
    if tipo in frases:
        frase = random.choice(frases[tipo])
        return jsonify({'frase': frase})
    return jsonify({'frase': 'No se encontró una frase para este tipo.'})

# ------------------- RUTAS CHAT MÚLTIPLE ----------------------

@main.route('/chat', methods=['GET', 'POST'])
def chat():
    chats = listar_chats()
    chat_actual = request.args.get('chat', 'default')

    if chat_actual not in chats and chat_actual != 'default':
        return redirect(url_for('main.chat'))

    historial = cargar_chat(chat_actual) if chat_actual != 'default' else cargar_historial()

    if request.method == 'POST':
        mensaje = request.form.get('mensaje')
        if mensaje:
            respuesta = responder_a_usuario(mensaje)
            respuesta_html = markdown.markdown(respuesta)

            historial.append({'usuario': mensaje, 'ia': respuesta_html})

            if chat_actual == 'default':
                guardar_historial(historial)
            else:
                guardar_chat(chat_actual, historial)

        return redirect(url_for('main.chat', chat=chat_actual))

    return render_template('chat.html', historial=historial, chats=chats, chat_actual=chat_actual)


@main.route('/chat/nuevo', methods=['POST'])
def nuevo_chat():
    nombre = request.form.get('nombre_chat', '').strip()
    if nombre:
        guardar_chat(nombre, [])
    return redirect(url_for('main.chat', chat=nombre))


@main.route('/chat/eliminar/<nombre>', methods=['POST'])
def borrar_chat(nombre):
    eliminar_chat(nombre)
    return redirect(url_for('main.chat'))

