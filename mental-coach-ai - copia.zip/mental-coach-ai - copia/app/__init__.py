from flask import Flask

def create_app():
    app = Flask(__name__, template_folder='../templates', static_folder='../static')

    # Clave secreta para habilitar sesiones
    app.secret_key = 'm1c0achAIC0nAm0rYc0nfi4nza'  # Puedes cambiar esto por algo más fuerte si quieres

    from .routes import main
    app.register_blueprint(main)

    return app
