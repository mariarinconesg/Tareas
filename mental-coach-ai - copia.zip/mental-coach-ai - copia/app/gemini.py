import google.generativeai as genai

genai.configure(api_key="AIzaSyBuLFRHRyd0wAOteUpHGlIQ_SRZ2arp-OQ")

# Este modelo sí está disponible según tu ejemplo
model = genai.GenerativeModel(model_name="models/gemini-2.0-flash")

def responder_a_usuario(mensaje_usuario):
    response = model.generate_content(mensaje_usuario)
    return response.text
