import json
import os

RUTA_HISTORIAL = 'historial.json'

def cargar_historial():
    if os.path.exists(RUTA_HISTORIAL):
        with open(RUTA_HISTORIAL, 'r', encoding='utf-8') as f:
            return json.load(f)
    return []

def guardar_historial(historial):
    with open(RUTA_HISTORIAL, 'w', encoding='utf-8') as f:
        json.dump(historial, f, ensure_ascii=False, indent=2)
